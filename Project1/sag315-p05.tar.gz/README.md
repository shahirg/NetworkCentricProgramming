Project1

for Test 3 in the test.sh I kept failing even though I had the correct output using perror

